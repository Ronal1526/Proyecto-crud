<!DOCTYPE html>
<html lang="es">
 <head>
 <meta charset="UTF-8">
 <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <meta http-equiv="X-UA-Compatible" content="ie=edge">
 <title>Livewire</title>
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-GLhlTQ8iRABdZLl6O3oVMWSktQOp6b7In1Zl3/Jr59b6EGGoI1aFkw7cmDA6j6gD" crossorigin="anonymous">
 <?php echo \Livewire\Livewire::styles(); ?>

 </head>
 <body>
 <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('students', [])->html();
} elseif ($_instance->childHasBeenRendered('3Qykhui')) {
    $componentId = $_instance->getRenderedChildComponentId('3Qykhui');
    $componentTag = $_instance->getRenderedChildComponentTagName('3Qykhui');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('3Qykhui');
} else {
    $response = \Livewire\Livewire::mount('students', []);
    $html = $response->html();
    $_instance->logRenderedChild('3Qykhui', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
 <?php echo \Livewire\Livewire::scripts(); ?>

//descargar CDN de jquery
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.min.js" integrity="sha384-mQ93GR66B00ZXjt0YO5KlohRA5SY2XofN4zfuZxLkoj1gXtW8ANNCe9d5Y3eG5eD" crossorigin="anonymous"></script>
 <script>
 window.livewire.on('studentAdded', () => {
 $('#addStudentModal').modal('hide');
 });
 </script>
 <script>
 window.livewire.on('studentUpdated', () => {
 $('#updateStudentModal').modal('hide');
 });
 </script>
  <script>
    window.livewire.on('studentDeleted', () => {
    $('#deletedStudentModal').modal('hide');
    });
    </script>
 </body>
</html>
<?php /**PATH C:\trabajos laravel\proyectoCRUD\resources\views/layouts/app.blade.php ENDPATH**/ ?>