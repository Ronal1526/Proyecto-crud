<div>
    <?php echo $__env->make('livewire.create', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('livewire.update', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('livewire.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <section>
        <div class="container">
        <div class="row">
        .<?php if(session()->has('message')): ?>
        <div class="alert alert-success">
        <?php echo e(session('message')); ?>

        </div>
        <?php endif; ?>
        <div class="card">
        <div class="card-header">
        <h3>
        All Students
        <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#addStudentModal">
        Add New Student
        </button>
        </h3>
        </div>
        <div class="card-body">
        <table class="table tabl-striped">
        <thead>
        <tr>
        <th>First Name</th>
        <th>Last Name</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Action</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
        <td><?php echo e($student->firstname); ?></td>
        <td><?php echo e($student->lastname); ?></td>
        <td><?php echo e($student->email); ?></td>
        <td><?php echo e($student->phone); ?></td>
        <td>
        <button type="button" class="btn btn-info" data-bs-toggle="modal" data-bs-target="#updateStudentModal" wire:click.prevent="edit(<?php echo e($student->id); ?>)">Edit</button>
        <button type="button" class="btn btn-info" data-bs-toggle="modal" data-bs-target="#deletedStudentModal" wire:click.prevent="destroy(<?php echo e($student->id); ?>)">Eliminar</button>
        </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
        </table>
        </div>
    </div>
</div>
</div>
</section>
</div><?php /**PATH C:\trabajos laravel\proyectoCRUD\resources\views/livewire/students.blade.php ENDPATH**/ ?>